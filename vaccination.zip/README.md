## Cách cài đặt

<p>download giải nén</p>
<p>vào thư mục vừa giải nén chạy Terminal</p>

# Chạy lần lượt các lệnh : 

<p>composer install</p>
<p>npm install</p>
<p>copy .env.example .env</p>
<p>php artisan key:generate</p>

# Tạo csdl có tên là : vaccination

<p>php artisan migrate</p>
<p>php artisan db:seed</p>

# Chạy project

php artisan serve

## Tài khoản ADMIN

<p>email: admin@gmail.com</p>
<p>pass: admin</p>
