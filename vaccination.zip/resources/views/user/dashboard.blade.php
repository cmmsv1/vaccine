@extends('layouts.dashboard')
@section('content')
<div class="py-4 px-4">
    <h2>USERR</h2>
</div>
@endsection