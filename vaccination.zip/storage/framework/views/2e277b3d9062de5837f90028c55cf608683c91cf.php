<?php if(count($products)>0): ?>
<div class="table-responsive mt-4">
    <table class="table table-striped table-bordered ">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên sản phẩm</th>
                <th>Giá</th>
                <th>Giá sale</th>
                <th>Tình trạng</th>
                <th>Số lượng</th>
                <th>Ảnh</th>
                <th>Tên danh mục</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody id="tbody">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                                         
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td>
                            <?php
                                echo number_format($item->regular_price, 0, ',', '.').'đ';
                            ?>
                        </td>
                        <td>
                            <?php
                                echo number_format($item->sale_price, 0, ',', '.').'đ';
                            ?>
                        </td>
                        <td><?php echo e($item->stock_status); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->image); ?>" ></td>
                        <td><?php echo e($item->category->name); ?></td>
                        
                        <td>
                            <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-primary edit"  style="margin: 0px 15px">
                                <i class="ti-pencil"></i>
                            </a>
                            <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-danger remove">
                                <i class="ti-trash"></i>
                            </a>
                        </td>
                            
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
    </table>
    
</div>
<div class="mt-2">
    <?php echo $products->render(); ?>

</div>
<?php else: ?>
    <p>Không tìm thấy sản phẩm nào phù hợp</p>
<?php endif; ?><?php /**PATH D:\web\web\backend\vaccination\resources\views/admin/oxy/read.blade.php ENDPATH**/ ?>