
<?php $__env->startSection('content'); ?>
    <div class="row px-4 py-4">
        <?php $__currentLoopData = $oxies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
                <a href="<?php echo e(route('oxy.detail',$item->slug)); ?>">
                    <img class="card-img-top" src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>">
                </a>
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($item->name); ?></h5>
                  <p class="card-text"><?php echo e($item->short_desc); ?></p>
                  <a href="<?php echo e(route('oxy.detail',$item->slug)); ?>" class="btn btn-primary">Chi tiết</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\vaccination\resources\views/shop/index.blade.php ENDPATH**/ ?>