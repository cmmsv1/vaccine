
<?php $__env->startSection('content'); ?>
    <div class="px-4 py-4">
      <h3 class="text-center">Đăng ký tiêm vaccine</h3>
      <div class="row container mx-auto">
        <div class="col-lg-12 mx-auto">
          <input type="hidden" id="check" value="<?php echo e(Auth::user()->confirm_register); ?>">
          <input type="hidden" id="type" value="<?php echo e(Auth::user()->type); ?>">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Loại vaccin</th>
                    <th>Số mũi</th>
                    <th>Địa chỉ</th>
                    <th>Ngày tiêm</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $vaccines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th><?php echo e($item->id); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->number); ?></td>
                    <td><?php echo e($item->address); ?></td>
                    <td><?php echo e($item->time . ' - ' .$item->date); ?></td>
                    <td><a data-href="<?php echo e($item->id); ?>" data-number='<?php echo e($item->number); ?>' data-name ='<?php echo e($item->name); ?>' style="color: #fff" class="btn btn-primary register">Đăng ký</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>
    </div>
    <script>
      $(document).ready(function () {
        $('.register').click(function (e) { 
            e.preventDefault();
            var check = $('#check').val();
            var type = $('#type').val();
            if((check == 2 && type == 'USER') || type == 'ADMIN'){
              var id = $(this).data('href');
              var number = $(this).data('number');
              var vaccine_name = $(this).data('name');
              console.log(vaccine_name);
              $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
              $.ajax({
                  type: "POST",
                  url: "<?php echo e(route('signupvacc.register')); ?>",
                  data: {
                      id:id,
                      number:number,
                      vaccine_name:vaccine_name
                  },
                  success: function (response) {
                      if(response.success){
                        swal({
                              title: "Success!",
                              text: response.success,
                              icon: "success",
                          });
                      }
                      if(response.error){
                        swal({
                              title: "Error!",
                              text: response.error,
                              icon: "warning",
                          });
                      }
                  }
              });
            }else if(check == 1 && type == 'USER'){
              swal({
                  title: "Error!",
                  text: 'Thông tin của bạn đang được xác minh! Vui lòng đợi',
                  icon: "warning",          
              });
            }
            else{
              swal({
                  title: "Error!",
                  text: 'Bạn cần điền thông tin trước',
                  icon: "warning",
                  buttons: ["Điền thông tin!", "Ở lại trang!"],
                  })
                  .then((ok) => {
                  if (ok) {
                      
                  } else {
                      window.location.href = "/user/formInfo";
                  }
              });
            }
            
        });
      });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\vaccination\resources\views/signupvacc/index.blade.php ENDPATH**/ ?>