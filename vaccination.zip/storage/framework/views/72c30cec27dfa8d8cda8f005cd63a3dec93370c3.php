
<?php $__env->startSection('content'); ?>
<div class="py-4 px-4">
    <h2>USERR</h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\vaccination\resources\views/user/dashboard.blade.php ENDPATH**/ ?>