<?php if(count($dates)>0): ?>
<div class="table-responsive mt-4">
    <table class="table table-striped table-bordered ">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên người đăng ký</th>
                <th>Số mũi</th>
                <th>Loại vaccine</th>
                <th>Ngày tiêm</th>
                <th>Trạng thái</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody id="tbody">
                <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                                         
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->user->name); ?></td>
                        <td><?php echo e($item->date_of_injection->number); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->date_of_injection->time .' - '. $item->date_of_injection->date); ?></td>
                        <td><?php echo e($item->status == 0 ? 'Đăng ký mới':'Đã tiêm'); ?></td>
                        <?php if($item->status == 0): ?>
                            <td>
                                <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-primary edit">
                                    <i class="ti-pencil"></i>
                                </a>
                            </td>
                        <?php else: ?>
                            <td>Xong</td>
                        <?php endif; ?>                     
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>
</div>
<div class="mt-2">
    <?php echo $dates->render(); ?>

</div>
<?php else: ?>
<p>Không tìm thấy ngày tiêm ...</p>
<?php endif; ?>
<?php /**PATH D:\web\web\backend\vaccination\resources\views/admin/register/read.blade.php ENDPATH**/ ?>