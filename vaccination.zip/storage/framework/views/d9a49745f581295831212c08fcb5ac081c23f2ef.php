<?php if($forms): ?>
<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Họ và tên</th>
            <th>Status</th>
            <th>Chi tiết</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->user->name); ?></td>
                <?php if($item->user->confirm_register == 1): ?>
                    <td>Đăng ký mới</td>
                <?php elseif($item->user->confirm_register == 2): ?>
                    <td>Đã xác nhận</td>
                <?php endif; ?>
                
                <td><a href="<?php echo e(route('admin.user-profile.detail',$item->id)); ?>" class="btn btn-primary">Chi tiết</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $forms->links(); ?>

<?php else: ?>
    <span>Không có user nào</span>
<?php endif; ?><?php /**PATH D:\web\web\backend\vaccination\resources\views/admin/user_profile/item.blade.php ENDPATH**/ ?>