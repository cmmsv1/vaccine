
<?php $__env->startSection('user'); ?>
<div class="container">
    <div class="py-4 px-4">
        <h3 class="text-center">Chi tiết đơn hàng</h3>
        <a href="<?php echo e(route('user.orders')); ?>" class="btn btn-primary"><i class="ti-arrow-left"></i></a>
        <div class="row mt-5">
            <div class="col-lg-10 mx-auto">
                <div class="row">
                    <div class="col-lg-5">
                        <h4 class="text-center">Thông tin khách hàng</h4>
                        <form method="post" id="changeStatus">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="order_id" value="<?php echo e($order->id); ?>">
                            <div class="form-group">
                                <label for="">Họ và tên</label>
                                <input id="" class="form-control" type="text" value="<?php echo e($order->name); ?>" <?php echo e($order->status != 0?'disabled':''); ?>>
                            </div>
                            <div class="form-group">
                                <label for="">Số điện thoại</label>
                                <input id="" class="form-control" type="number" value="<?php echo e($order->phone); ?>" <?php echo e($order->status != 0?'disabled':''); ?>>
                            </div>
                            <div class="form-group">                          
                            <div class="form-group">
                                    <label for="">Địa chỉ:</label>
                                    <textarea id="my-textarea" class="form-control" <?php echo e($order->status != 0?'disabled':''); ?> rows="3"><?php echo e($order->address); ?></textarea>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="">Tin nhắn:</label>
                                <textarea class="form-control" id="message" <?php echo e($order->status != 0?'disabled':''); ?> rows="2"><?php echo e($order->message); ?></textarea>
                            </div>
                            <?php if($order->status != 0): ?>
                                <span>Cảm ơn bạn đã đặt hàng</span>
                            <?php else: ?>
                                <button type="submit" class="btn btn-primary">Cập nhật</button>
                            <?php endif; ?>
                           
                        </form>
                    </div>
                    <div class="col-lg-7">
                        <h4 class="text-center">Sản phẩm mua</h4>
                        <table class="table table-striped table-bordered mt-3">
                            <thead>
                                <tr>
                                    <td>Tên sản phẩm</td>
                                    <td>Số lượng</td>
                                    <td>Giá</td>
                                    <td>Ảnh</td>
                                </tr>
                            </thead>
                            <tbody>
                                    <tr>
                                        <td><?php echo e($oxy->name); ?></td>
                                        <td><?php echo e($order->quantity); ?></td>
                                        <td><?php echo number_format($oxy->price, 0, ',', '.').'đ';?></td>
                                        <td><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($oxy->image); ?>" alt=""></td>
                                    </tr>
                                
                            </tbody>
                        </table>
                        <div style="margin-top: 20px"><span>Tổng tiền: <?php echo number_format($order->total, 0, ',', '.').'đ';?></span></div>
                        
                       
                    </div>
                </div>
                
            </div>
            
        </div>
        
</div>
<script>
    $(document).ready(function () {
        
        $('#changeStatus').submit(function (e) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            e.preventDefault();
            var message = $('#message').val();
            var id = $('#order_id').val();
            $.ajax({
                type: "post",
                url: "/user/orders/update/"+id,
                data: {
                    status:status,
                    message:message
                },
                success: function (response) {
                    swal({
                        title: "Success!",
                        text: response.message,
                        icon: "success",
                    });
                }
            });
        });
        
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\vaccination\resources\views/user/order/detail.blade.php ENDPATH**/ ?>