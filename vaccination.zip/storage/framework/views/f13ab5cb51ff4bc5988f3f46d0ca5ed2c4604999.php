<?php if(count($categories)>0): ?>
<div class="table-responsive mt-4">
    <table class="table table-striped table-bordered ">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Slug</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody id="tbody">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                                         
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->slug); ?></td>
                        <td>
                            <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-primary edit"  style="margin: 0px 15px">
                                <i class="ti-pencil"></i>
                            </a>
                            <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-danger remove">
                                <i class="ti-trash"></i>
                            </a>
                        </td>                      
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>
</div>
<div class="mt-2">
    <?php echo $categories->render(); ?>

</div>
<?php else: ?>
<p>Không tìm thấy danh mục nào phù hợp</p>
<?php endif; ?>
<?php /**PATH D:\web\web\backend\vaccination\resources\views/admin/oxy_producer/read.blade.php ENDPATH**/ ?>